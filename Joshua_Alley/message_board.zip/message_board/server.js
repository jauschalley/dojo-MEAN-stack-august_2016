var express = require('express'),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose'),
    path = require('path'),
    port = 8000,
    app = express();

// Set up body-parser to parse form data
app.use(bodyParser.urlencoded({extended: false}));
//This just points our server at our views which are located in folder called 'views'
app.set('views', path.join(__dirname, './views'));
//EJS is being set as our view engine
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost/message_db');

var Schema = mongoose.Schema;

var MessageSchema = new mongoose.Schema({
  name: { type: String, required: true },
  message: { type: String, required: true },
  _comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
});

var CommentSchema = new mongoose.Schema({
  name: {type: String, required: true },
  comment: {type: String, required: true },
   _message: {type: Schema.Types.ObjectId, ref: 'Message'}
});



mongoose.model('Message', MessageSchema);
var Message = mongoose.model('Message');
mongoose.model('Comment', CommentSchema);
var Comment = mongoose.model('Comment');



// Here are our routes!

app.get('/', function(req, res){
  Message.find({})
    .populate('_comments')
    .exec(function(err, messages) {
      res.render('index', {messages});
    });
});


app.post('/post_message', function(req, res){
  var new_message = new Message({
    name: req.body.name,
    message: req.body.message
  });
  new_message.save(function(err){
    if(err) {console.log(err);}
    else{
      res.redirect('/')
    }
   });
});

app.post('/post_comment/:id', function(req, res){
  Message.findOne({_id: req.params.id}, function(err, message){
    var new_comment = new Comment({name: req.body.name, comment: req.body.comment});
    new_comment._message = message._id;
    new_comment.save(function(err){
      message._comments.push(new_comment);
      message.save(function(err){
        if(err) {
          console.log('Comment did not post.')
        }
        else{
          res.redirect('/')
        }
      })
    })
  })



});

app.listen(port);
console.log("Listening on 8000.")
